const firebaseConfig = {
  apiKey: "AIzaSyAFyfIy6mfgkrxJm0U-fryTc5wnIHeSa9w",
  authDomain: "jatin-chahal-chat.firebaseapp.com",
  projectId: "jatin-chahal-chat",
  storageBucket: "jatin-chahal-chat.appspot.com",
  messagingSenderId: "296327802068",
  appId: "1:296327802068:web:580a7a22c7c3056a2e1f41"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

const userSpan = document.getElementById("username");
const msgBox = document.getElementById("messages");
const input = document.getElementById("msg");

auth.onAuthStateChanged(user => {
  if (!user) window.location.href = "index.html";
  else userSpan.innerText = "Logged in as " + user.email;
});

function sendMessage() {
  const text = input.value.trim();
  if (!text) return;
  const user = auth.currentUser;
  db.ref("messages").push({
    sender: user.email,
    text: text,
    time: new Date().toLocaleTimeString()
  });
  input.value = "";
}

db.ref("messages").on("child_added", snap => {
  const m = snap.val();
  const div = document.createElement("div");
  div.className = "msg";
  div.innerHTML = `<span class="sender">${m.sender}</span><br><span class="content">${m.text}</span><br><small>${m.time}</small>`;
  msgBox.appendChild(div);
  msgBox.scrollTop = msgBox.scrollHeight;
});

function logout() {
  auth.signOut().then(() => window.location.href = "index.html");
}
